# plg_content_lupotoy
This Joomla content plugin display toy(s)
