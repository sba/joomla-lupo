plg_search_lupo
===============

LUPO Joomla Search Plugin for toys
