# mod_lupo_loginlink
Joomla Module to show loginlink to mod_lupo_login
