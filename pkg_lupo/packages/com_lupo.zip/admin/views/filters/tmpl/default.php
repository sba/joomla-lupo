<?php
/**
 * @package     LUPO
 * @copyright   Copyright (C) databauer / Stefan Bauer
 * @author      Stefan Bauer
 * @link        https://www.ludothekprogramm.ch
 * @license     License GNU General Public License version 2 or later
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted Access');

?>
<style>
    .right {
        text-align: right !important;
    }
</style>

<div id="j-sidebar-container" class="j-sidebar-container j-sidebar-visible">
    <?php echo JHtmlSidebar::render(); ?>
</div>
<div id="j-main-container" class="span10 j-toggle-main">

    <table class="table table-striped table-hover">
        <thead>
        <tr>
            <th width="25%">
                Kategorie
            </th>
            <th width="15%">
                Typ
            </th>
            <th>
                Suchfilter
            </th>
            <th>
                Filter-Style
            </th>
            <th>
                &nbsp;
            </th>
        </tr>
        </thead>
        <tbody>
        <?php if (!empty($this->items)) : ?>
            <?php foreach ($this->items as $i => $row) :
                $link = JRoute::_('index.php?option=com_lupo&view=filter&task=filter.edit&id=' . $row['id'] . '&filter_type=' . $row['filter_type']);
                $subsets = json_decode($row['subsets'] ?? '', true);
                ?>
                <tr>
                    <td><?= $row['title'] ?></td>
                    <td><?= $row['filter_type'] === 'agecategory' ? 'Alterskategorie' : 'Kategorie' ?></td>
                    <td><?php

                        if (is_array($subsets)) {
                            foreach ($subsets['filters'] as $caption => $subset) {
                                ?>
                                <b><?= $caption ?></b><br>
                                <?php if (!empty($subset['categories'])): ?>
                                    <em class="text-muted">Kategorien:</em> <?= implode(', ', $subset['categories']) ?><br>
                                <?php endif; ?>
                                <?php if (!empty($subset['agecategories'])): ?>
                                    <em class="text-muted">Alterskategorien:</em> <?= implode(', ', $subset['agecategories']) ?><br>
                                <?php endif; ?>
                                <?php if (!empty($subset['genres'])): ?>
                                    <em class="text-muted">Genres:</em> <?= implode(', ', $subset['genres']) ?><br>
                                <?php endif; ?>
                                <?php if (!empty($subset['players'])): ?>
                                    <em class="text-muted">Players:</em> <?= implode(', ', $subset['players']) ?><br>
                                <?php endif; ?>
                                <br>
                                <?php
                            }
                        }
                        ?>
                    </td>
                    <td><?= isset($subsets['style']) && $subsets['style']!=null?$subsets['style']:'dropdown' ?></td>
                    <td class="right">
                        <a href="<?php echo $link; ?>" class="btn btn-small">
                            <span class="icon-edit"></span> Bearbeiten
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

</div>

