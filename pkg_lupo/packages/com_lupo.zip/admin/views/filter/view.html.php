<?php
/**
 * @package     LUPO
 * @copyright   Copyright (C) databauer / Stefan Bauer
 * @author      Stefan Bauer
 * @link        https://www.ludothekprogramm.ch
 * @license     License GNU General Public License version 2 or later
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

/**
 * Lupo View
 */
class LupoViewFilter extends JViewLegacy {
	/**
	 * Lupo view display method
	 * @return void
	 */
	function display($tpl = null) {
		// Get data from the model
		$this->item = $this->get('Category');

		$this->categories    = $this->get('Categories');
		$this->agecategories = $this->get('Agecategories');
		$this->genres        = $this->get('Genres');
		$this->players       = $this->get('Players');


		// Set the submenu
		LupoHelper::addSubmenu('filter');

		// Set the toolbar
		$this->addToolBar();

		// Display the template
		parent::display($tpl);
	}

	/**
	 * Setting the toolbar
	 */
	protected function addToolBar() {
		JToolBarHelper::title(JText::_('LUPO'));

		JToolBarHelper::apply('filter.apply');
		JToolBarHelper::save('filter.save');
		JToolbarHelper::cancel('filter.cancel');

		JToolBarHelper::preferences('com_lupo');
	}


}
