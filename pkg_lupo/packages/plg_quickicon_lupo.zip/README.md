plg_quickicon_lupo
===============

Adds LUPO component link to Joomla administrator quick icons
