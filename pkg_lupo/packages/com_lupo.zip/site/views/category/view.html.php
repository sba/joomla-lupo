<?php
/**
 * @package     LUPO
 * @copyright   Copyright (C) databauer / Stefan Bauer
 * @author      Stefan Bauer
 * @link        https://www.ludothekprogramm.ch
 * @license     License GNU General Public License version 2 or later
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

/**
 * HTML View class for the LUPO Component
 */
class LupoViewCategory extends JViewLegacy {
	// Overwriting JView display method
	function display($tpl = null) {
		$app = JFactory::getApplication();

		// Check model errors – only if the model is actually registered (legacy controller sets data directly).
		$errors = [];

		if (isset($this->_models['category'])) {
			$model = $this->getModel('Category');

			if ($model && method_exists($model, 'getErrors')) {
				$errors = $model->getErrors();
			}
		}

		if ($errors) {
			JFactory::getApplication()->enqueueMessage(implode('<br />', $errors), 'error');
			return false;
		}

		// Check for empty title and add site name if param is set
		$title = $this->category['title'] ?? $this->title;
		if (empty($title)) {
			$title = $app->get('sitename');
		} elseif ($app->get('sitename_pagetitles', 0) == 1) {
			$title = JText::sprintf('JPAGETITLE', $app->get('sitename'), $title);
		} elseif ($app->get('sitename_pagetitles', 0) == 2) {
			$title = JText::sprintf('JPAGETITLE', $title, $app->get('sitename'));
		}

		JFactory::getDocument()->setTitle($title);

		// Display the view
		parent::display($tpl);
	}
}
