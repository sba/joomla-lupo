# plg_content_lupototaltoys
This Joomla content plugin shows the total number of toys
